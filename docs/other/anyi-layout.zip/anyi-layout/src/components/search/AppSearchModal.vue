<!--
 * Copyright (c) 2021-present ZHOUXUANHONG(安一老厨)<anyilanxin@aliyun.com>
 *
 * 本软件 AnYi Cloud Vue EE为商业授权软件。未经过商业授权禁止使用，违者必究。
 *
 * AnYi Cloud Vue EE为商业授权软件，您在使用过程中，需要注意以下几点：
 *   1.不允许在国家法律法规规定的范围外使用，如出现违法行为作者本人不承担任何责任；
 *   2.软件使用的第三方依赖皆为开源软件，如需要修改第三方依赖请遵循第三方依赖附带的开源协议，因擅自修改第三方依赖所引起的争议，作者不承担任何责任；
 *   3.不得基于AnYi Cloud EE Vue的基础，修改包装而成一个与AnYi Cloud EE、AnYi Zeebe EE、AnYi Standalone EE功能类似的程序，进行销售或发布，参与同类软件产品市场的竞争；
 *   4.不得将软件源码以任何开源方式公布出去；
 *   5.不得对授权进行出租、出售、抵押或发放子许可证；
 *   6.您可以直接使用在自己的网站或软件产品中，也可以集成到您自己的商业网站或软件产品中进行出租或销售；
 *   7.您可以对上述授权软件进行必要的修改和美化，无需公开修改或美化后的源代码；
 *   8.本软件中使用了bpmn js,使用请遵循bpmn.io开源协议：
 *     https://github.com/bpmn-io/bpmn-js/blob/develop/LICENSE
 *   9.除满足上面条款外，在其他商业领域使用不受影响。同时作者为商业授权使用者在使用过程中出现的纠纷提供协助。
 -->
<script lang="ts" setup>
import { useI18n } from '@anyi/locale'
import { useRefs } from '@anyi/hooks'
import { computed, unref, ref } from 'vue'
import AppSearchFooter from './AppSearchFooter.vue'
import { useMenuSearch } from './useMenuSearch'
import { clickOutside as vClickOutside } from '@anyi/directives'
import { context } from '../../../bridge'
const { useDesign, useAppInject } = context
defineProps({
  visible: { type: Boolean },
})

const emit = defineEmits(['close'])

const scrollWrap = ref(null)

const { t } = useI18n()
const { prefixCls } = useDesign('app-search-modal')
const [refs, setRefs] = useRefs()
const { getIsMobile } = useAppInject()

const {
  handleSearch,
  searchResult,
  keyword,
  activeIndex,
  handleEnter,
  handleMouseenter,
} = useMenuSearch(refs, scrollWrap, emit)

const getIsNotData = computed(
  () => !keyword || unref(searchResult).length === 0,
)

const getClass = computed(() => {
  return [
    prefixCls,
    {
      [`${prefixCls}--mobile`]: unref(getIsMobile),
    },
  ]
})

function handleClose() {
  searchResult.value = []
  emit('close')
}
</script>

<template>
  <Teleport to="body">
    <transition name="zoom-fade" mode="out-in">
      <div :class="getClass" @click.stop v-if="visible">
        <div :class="`${prefixCls}-content`" v-click-outside="handleClose">
          <div :class="`${prefixCls}-input__wrapper`">
            <VbenInput
              :class="`${prefixCls}-input`"
              :placeholder="t('common.searchText')"
              allow-clear
              autofocus
              @input="handleSearch"
            >
              <template #prefix>
                <VbenIconify
                  :size="24"
                  color="gray"
                  icon="ant-design:search-outlined"
                />
              </template>
            </VbenInput>
            <span :class="`${prefixCls}-cancel`" @click="handleClose">
              {{ t('common.cancelText') }}
            </span>
          </div>

          <div :class="`${prefixCls}-not-data`" v-show="getIsNotData">
            {{ t('component.app.searchNotData') }}
          </div>

          <ul
            :class="`${prefixCls}-list`"
            v-show="!getIsNotData"
            ref="scrollWrap"
          >
            <li
              :ref="setRefs(index)"
              v-for="(item, index) in searchResult"
              :key="item.path"
              :data-index="index"
              @mouseenter="handleMouseenter"
              @click="handleEnter"
              :class="[
                `${prefixCls}-list__item`,
                {
                  [`${prefixCls}-list__item--active`]: activeIndex === index,
                },
              ]"
            >
              <div :class="`${prefixCls}-list__item-icon`">
                <VbenIconify
                  :icon="item.icon || 'mdi:form-select'"
                  :size="20"
                />
              </div>
              <div :class="`${prefixCls}-list__item-text`">
                {{ item.name }}
              </div>
              <div :class="`${prefixCls}-list__item-enter`">
                <VbenIconify icon="ant-design:enter-outlined" :size="20" />
              </div>
            </li>
          </ul>
          <AppSearchFooter />
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<style lang="less" scoped>
// @prefix-cls: ~'@{namespace}-app-search-modal';
// @footer-prefix-cls: ~'@{namespace}-app-search-footer';
.vben-app-search-modal {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 800;
  display: flex;
  width: 100%;
  height: 100%;
  padding-top: 50px;
  background-color: rgb(0 0 0 / 25%);
  justify-content: center;

  &--mobile {
    padding: 0;

    > div {
      width: 100%;
    }

    .vben-app-search-modal-input {
      width: calc(100% - 38px);
    }

    .vben-app-search-modal-cancel {
      display: inline-block;
    }

    .vben-app-search-modal-content {
      width: 100%;
      height: 100%;
      border-radius: 0;
    }

    .vben-app-search-footer {
      display: none;
    }

    .vben-app-search-modal-list {
      height: calc(100% - 80px);
      max-height: unset;

      &__item {
        &-enter {
          opacity: 0% !important;
        }
      }
    }
  }

  &-content {
    position: relative;
    width: 632px;
    margin: 0 auto auto;
    background-color: #fff;
    border-radius: 16px;
    box-shadow: 0 25px 50px -12px rgb(0 0 0 / 25%);
    flex-direction: column;
  }

  &-input__wrapper {
    display: flex;
    padding: 14px 14px 0;
    justify-content: space-between;
    align-items: center;
  }

  &-input {
    width: 100%;
    height: 48px;
    font-size: 1.5em;
    color: #1c1e21;
    border-radius: 6px;

    span[role='img'] {
      color: #999;
    }
  }

  &-cancel {
    display: none;
    font-size: 1em;
    color: #666;
  }

  &-not-data {
    display: flex;
    width: 100%;
    height: 100px;
    font-size: 0.9;
    color: rgb(150 159 175);
    align-items: center;
    justify-content: center;
  }

  &-list {
    max-height: 472px;
    padding: 0 14px;
    padding-bottom: 20px;
    margin: 0 auto;
    margin-top: 14px;
    overflow: auto;

    &__item {
      position: relative;
      display: flex;
      height: 56px;
      padding-bottom: 4px;
      padding-left: 14px;
      margin-top: 8px;
      font-size: 14px;
      color: #000000d9;
      cursor: pointer;
      background-color: #fff;
      border-radius: 4px;
      box-shadow: 0 1px 3px 0 #d4d9e1;
      align-items: center;

      > div:first-child,
      > div:last-child {
        display: flex;
        align-items: center;
      }

      &--active {
        color: #fff;
        background-color: #0960bd;

        .vben-app-search-modal-list__item-enter {
          opacity: 100%;
        }
      }

      &-icon {
        width: 30px;
      }

      &-text {
        flex: 1;
      }

      &-enter {
        width: 30px;
        opacity: 0%;
      }
    }
  }
}

:deep(.n-input__input) {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
