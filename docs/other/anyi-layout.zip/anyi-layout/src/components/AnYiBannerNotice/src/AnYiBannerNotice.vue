<!--
 * Copyright (c) 2021-present ZHOUXUANHONG(安一老厨)<anyilanxin@aliyun.com>
 *
 * 本软件 AnYi Cloud Vue EE为商业授权软件。未经过商业授权禁止使用，违者必究。
 *
 * AnYi Cloud Vue EE为商业授权软件，您在使用过程中，需要注意以下几点：
 *   1.不允许在国家法律法规规定的范围外使用，如出现违法行为作者本人不承担任何责任；
 *   2.软件使用的第三方依赖皆为开源软件，如需要修改第三方依赖请遵循第三方依赖附带的开源协议，因擅自修改第三方依赖所引起的争议，作者不承担任何责任；
 *   3.不得基于AnYi Cloud EE Vue的基础，修改包装而成一个与AnYi Cloud EE、AnYi Zeebe EE、AnYi Standalone EE功能类似的程序，进行销售或发布，参与同类软件产品市场的竞争；
 *   4.不得将软件源码以任何开源方式公布出去；
 *   5.不得对授权进行出租、出售、抵押或发放子许可证；
 *   6.您可以直接使用在自己的网站或软件产品中，也可以集成到您自己的商业网站或软件产品中进行出租或销售；
 *   7.您可以对上述授权软件进行必要的修改和美化，无需公开修改或美化后的源代码；
 *   8.本软件中使用了bpmn js,使用请遵循bpmn.io开源协议：
 *     https://github.com/bpmn-io/bpmn-js/blob/develop/LICENSE
 *   9.除满足上面条款外，在其他商业领域使用不受影响。同时作者为商业授权使用者在使用过程中出现的纠纷提供协助。
 -->
<template>
  <div v-if="bannerNoticeList && bannerNoticeList.length > 0">
    <div
      class="anyi-banner-notice"
      :class="{ 'anyi-banner-notice-rounded': tabType == 'rounded' }"
    >
      <a-alert banner closable @close="handleClose">
        <template #title>
          <div
            ref="contentParentDomRef"
            class="content-banner-notice-parent"
            @mouseenter="handleAnimate(0)"
            @mouseleave="handleAnimate(1)"
          >
            <div ref="contentDomRef" class="content-banner-notice">
              {{ noticeInfo }}
            </div>
          </div>
        </template>
      </a-alert>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, nextTick, computed } from 'vue'
// import { useAppStore } from '@/store'

// const appStore = useAppStore()

const contentParentDomRef = ref()
const contentDomRef = ref()
const noticeInfo = ref('')
const animate = ref()
const isAnimating = ref(false)
const bannerNoticeList = ref<string[]>([])
const tabType = ref('rounded')
// const tabType = computed(() => {
//   return appStore.tabType || 'rounded'
// })

// function handleSubscribe() {
//   // subscribe(loginFirstSubscribe, handleBannerNotice);
// }

async function startAnimate() {
  while (bannerNoticeList.value && bannerNoticeList.value.length > 0) {
    noticeInfo.value = bannerNoticeList.value[0] as string
    const ballEl = contentParentDomRef.value
    if (ballEl) {
      const { offsetWidth } = ballEl
      animate.value = contentDomRef.value.animate(
        {
          transform: [`translateX(${offsetWidth}px)`, `translateX(0px)`],
        },
        {
          duration: 3000,
          fill: 'forwards',
          easing: 'ease-out',
        },
      )
      // eslint-disable-next-line no-await-in-loop
      await animate.value.finished
      // 暂停部分
      const contentEl = contentDomRef.value
      const itemWidth = contentEl.getBoundingClientRect().width
      const gapWidth = Math.max(0, itemWidth - offsetWidth + 50)
      const duration = Math.max(0, Math.floor(gapWidth / 200) * 1000)
      animate.value = contentEl.animate(
        {
          transform: [`translateX(0px)`, `translateX(-${gapWidth}px)`],
        },
        {
          duration,
          delay: 3000,
          fill: 'forwards',
          easing: 'linear',
        },
      )
      // eslint-disable-next-line no-await-in-loop
      await animate.value.finished
      // 滑出部分
      animate.value = contentEl.animate(
        {
          transform: [
            `translateX(-${gapWidth}px)`,
            `translateX(-${itemWidth}px)`,
          ],
        },
        {
          duration: 1000,
          fill: 'forwards',
          easing: 'ease-in',
        },
      )
      // eslint-disable-next-line no-await-in-loop
      await animate.value.finished
    }
    bannerNoticeList.value.splice(0, 1)
  }
  isAnimating.value = false
}

function handleBannerNotice(data: any) {
  const message = JSON.parse(data.body)

  if (message && message.length > 0) {
    bannerNoticeList.value.push(...message)
    if (!isAnimating.value) {
      isAnimating.value = true
      setTimeout(startAnimate, 2000)
    }
  }
}

function handleAnimate(type: number) {
  if (animate.value?.playState !== 'finished') {
    if (type === 0) {
      animate.value?.pause()
    } else {
      animate.value?.play()
    }
  }
}
function handleClose() {
  bannerNoticeList.value = []
}

onMounted(() => {
  nextTick(() => {
    const data = {
      body: '["sdfsdf","sdfsdf","sdfsdfsdfsdfsdf"]',
    }
    handleBannerNotice(data)
  })
})
</script>

<style lang="less" scoped>
.anyi-banner-notice-rounded {
  background-color: var(--color-fill-3);
  padding-bottom: 5px;
}
.anyi-banner-notice {
  .arco-alert-with-title {
    padding: 0px 5px !important;
    align-items: center !important;
  }

  .content-banner-notice-parent {
    margin: 0px 5px;
    height: 30px;
    line-height: 30px;
    white-space: nowrap;
    text-align: center;
    position: relative;
    align-items: center;
    overflow: hidden;

    .content-banner-notice {
      position: absolute;
      height: 100%;
      white-space: nowrap;
      transition-timing-function: linear;
    }
  }
}
</style>
