<!--
 * Copyright (c) 2021-present ZHOUXUANHONG(安一老厨)<anyilanxin@aliyun.com>
 *
 * 本软件 AnYi Cloud Vue EE为商业授权软件。未经过商业授权禁止使用，违者必究。
 *
 * AnYi Cloud Vue EE为商业授权软件，您在使用过程中，需要注意以下几点：
 *   1.不允许在国家法律法规规定的范围外使用，如出现违法行为作者本人不承担任何责任；
 *   2.软件使用的第三方依赖皆为开源软件，如需要修改第三方依赖请遵循第三方依赖附带的开源协议，因擅自修改第三方依赖所引起的争议，作者不承担任何责任；
 *   3.不得基于AnYi Cloud EE Vue的基础，修改包装而成一个与AnYi Cloud EE、AnYi Zeebe EE、AnYi Standalone EE功能类似的程序，进行销售或发布，参与同类软件产品市场的竞争；
 *   4.不得将软件源码以任何开源方式公布出去；
 *   5.不得对授权进行出租、出售、抵押或发放子许可证；
 *   6.您可以直接使用在自己的网站或软件产品中，也可以集成到您自己的商业网站或软件产品中进行出租或销售；
 *   7.您可以对上述授权软件进行必要的修改和美化，无需公开修改或美化后的源代码；
 *   8.本软件中使用了bpmn js,使用请遵循bpmn.io开源协议：
 *     https://github.com/bpmn-io/bpmn-js/blob/develop/LICENSE
 *   9.除满足上面条款外，在其他商业领域使用不受影响。同时作者为商业授权使用者在使用过程中出现的纠纷提供协助。
 -->
<template>
  <div :class="layoutClass">
    <logo
      :class="bem('logo')"
      v-if="(showSidebarLogo || getIsMobile) && getMenuShowLogo"
      :showTitle="!getCollapsed"
    />
    <a-menu
      :collapsed="getCollapsed"
      @collapse="setCollapse"
      :collapsed-width="collapsedWidth"
      :collapsed-icon-size="22"
      :auto-scroll-into-view="true"
      :root-indent="18"
      :auto-open-selected="true"
      :level-indent="24"
      style="height: 100%"
      ref="menuRef"
      :mode="props.mode"
      :accordion="menu.accordion"
    >
      <SubMenu
        v-for="subItem in menuList"
        :key="subItem.key"
        :first-menu-item="true"
        :menu-item="subItem"
      />
    </a-menu>
    <div
      class="menu-fold"
      v-if="
        getMenuType == MenuTypeEnum.SIDEBAR || getMenuType == MenuTypeEnum.MIX
      "
    >
      这段按钮
    </div>
  </div>
</template>

<script lang="ts" setup>
import { MenuTypeEnum } from '@anyi/constants'
import SubMenu from './sub-menu.vue'
import { ref, h, onMounted, unref, computed } from 'vue'
import { createNamespace, mapTree } from '@anyi/utils'
import { context } from '../../../bridge'
import {
  RouteLocationNormalizedLoaded,
  RouterLink,
  useRouter,
} from 'vue-router'
import { useI18n } from '@anyi/locale'
import { REDIRECT_NAME } from '@anyi/constants'
import { renderIcon } from '../index'
import { baseHandler } from '../handler'

import { getMenus, listenerRouteChange } from '@anyi/router'
import { useAppConfig } from '@anyi/hooks'
import {
  SIDE_BAR_MINI_WIDTH,
  SIDE_BAR_SHOW_TIT_MINI_WIDTH,
} from '@anyi/constants'

const props = defineProps({
  mode: {
    type: String,
    default: () => 'vertical',
  },
})
const { Logo, useMenuSetting, useAppInject } = context
// const { getAccordion } = useMenuSetting()
const { getMenuShowLogo } = useMenuSetting() as any

const {
  getAccordion,
  getFixed,
  getMenuFixed,
  getCollapsed,
  toggleCollapsed,
  getMenuType,
} = useMenuSetting() as any
const { getIsMobile } = useAppInject() as any
const { menu, isMixSidebar, getCollapsedShowTitle, sidebar, isSidebar } =
  useAppConfig()
const showSidebarLogo = computed(() => {
  return unref(isSidebar) || unref(isMixSidebar)
})

const collapsedWidth = computed(() => {
  return unref(sidebar).collapsedWidth || SIDE_BAR_MINI_WIDTH
})

const getMixSidebarWidth = computed(() => {
  return unref(getCollapsed)
    ? SIDE_BAR_MINI_WIDTH
    : SIDE_BAR_SHOW_TIT_MINI_WIDTH
})
const { bem } = createNamespace('layout-menu')
const layoutClass = computed(() => {
  let clas = bem()
  if (
    (unref(getMenuType) == MenuTypeEnum.MIX && !unref(getMenuShowLogo)) ||
    !unref(getMenuShowLogo)
  ) {
    clas += ' fix-sidbar-top'
  } else {
    clas += ' fix-sidbar'
  }
  return clas
})
const { t } = useI18n()
const { currentRoute } = useRouter()

const menuRef = ref(null)
const menuList = ref<any[]>([])
const activeKey = ref<string[]>([])

const getMenuCollapsed = computed(() => {
  if (unref(isMixSidebar)) return true
  return unref(sidebar).collapsed
})

// TODO 静态路由 待实现
onMounted(async () => {
  const menus = await getMenus()
  menuList.value = menus
})

listenerRouteChange((route) => {
  if (route.name === REDIRECT_NAME) return

  const currentActiveMenu = route.meta?.currentActiveMenu as string
  handleMenuChange(route)

  if (currentActiveMenu) {
    activeKey.value = currentActiveMenu
  }
})
const setCollapse = (val: boolean) => {
  console.log('-------val-------', unref(getIsMobile))
  if (!unref(getIsMobile)) {
    console.log('-------val---11----', val)
    toggleCollapsed()
  }
}
async function handleMenuChange(route?: RouteLocationNormalizedLoaded) {
  const menu = route || unref(currentRoute)
  activeKey.value = menu.name
}

// 路由格式化
const routerToMenu = (item: RouteRecordItem) => {
  const { name, children, meta, icon } = item
  const title = t(meta.title as string)
  return {
    label: () => {
      if (children) {
        return title
      }
      return h(
        RouterLink,
        {
          to: {
            name,
          },
        },
        { default: () => title },
      )
    },
    key: name,
    icon: renderIcon(icon),
  }
}
</script>

<style lang="less" scoped>
.layout-menu {
  display: flex;
  flex-direction: column;

  &__logo {
    flex-shrink: 0;
    border-bottom: 1px solid var(--color-border);
  }

  .menu-fold {
    height: 40px;
    width: 100%;
    position: absolute;
    padding-top: 2px;
    bottom: 0px;
    right: 0px;
  }
}
.layout-menu.fix-sidbar-top {
  height: 100%;
  overflow: hidden;
  .arco-menu-vertical {
    height: 100%;
    :deep(.arco-menu-inner) {
      height: calc(100% - 40px) !important;
    }
  }
}

.layout-menu.fix-sidbar {
  height: 100%;
  overflow: hidden;
  .arco-menu-vertical {
    height: 100%;
    :deep(.arco-menu-inner) {
      height: calc(100% - 84px) !important;
    }
  }
}
</style>
