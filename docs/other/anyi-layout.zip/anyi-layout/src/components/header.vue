<!--
 * Copyright (c) 2021-present ZHOUXUANHONG(安一老厨)<anyilanxin@aliyun.com>
 *
 * 本软件 AnYi Cloud Vue EE为商业授权软件。未经过商业授权禁止使用，违者必究。
 *
 * AnYi Cloud Vue EE为商业授权软件，您在使用过程中，需要注意以下几点：
 *   1.不允许在国家法律法规规定的范围外使用，如出现违法行为作者本人不承担任何责任；
 *   2.软件使用的第三方依赖皆为开源软件，如需要修改第三方依赖请遵循第三方依赖附带的开源协议，因擅自修改第三方依赖所引起的争议，作者不承担任何责任；
 *   3.不得基于AnYi Cloud EE Vue的基础，修改包装而成一个与AnYi Cloud EE、AnYi Zeebe EE、AnYi Standalone EE功能类似的程序，进行销售或发布，参与同类软件产品市场的竞争；
 *   4.不得将软件源码以任何开源方式公布出去；
 *   5.不得对授权进行出租、出售、抵押或发放子许可证；
 *   6.您可以直接使用在自己的网站或软件产品中，也可以集成到您自己的商业网站或软件产品中进行出租或销售；
 *   7.您可以对上述授权软件进行必要的修改和美化，无需公开修改或美化后的源代码；
 *   8.本软件中使用了bpmn js,使用请遵循bpmn.io开源协议：
 *     https://github.com/bpmn-io/bpmn-js/blob/develop/LICENSE
 *   9.除满足上面条款外，在其他商业领域使用不受影响。同时作者为商业授权使用者在使用过程中出现的纠纷提供协助。
 -->
<template>
  <div vertical style="flex-wrap: nowrap">
    <div
      class="n-space h-48px shadow anyi-layout-header"
      style="
        display: flex;
        flex-flow: row wrap;
        flex-wrap: nowrap;
        justify-content: space-between;
        align-items: center;
        gap: 8px 12px;
      "
    >
      <slot name="logo">
        <Logo
          v-if="showHeaderLogo"
          :style="{
            width: getMenuWidth + 'px',
            maxWidth: getMenuWidth + 'px',
          }"
        />
        <slot name="breadcrumb">
          <LayoutBreadcrumb v-if="!(isTopMenu || (isMix && menu.split))" />
        </slot>
      </slot>
      <slot name="menu"></slot>
      <div class="pl-8px pr-8px">
        <slot name="buttons">
          <div
            class="p-1"
            style="
              display: flex;
              flex-flow: row wrap;
              flex-wrap: nowrap;
              justify-content: flex-start;
              align-items: center;
              gap: 16px;
            "
          >
            <AppSearch v-if="getShowSearch" />
            <AppNotify :is-dark="isDark" v-if="getShowNotice" />
            <AppFullScreen v-if="getShowFullScreen" />
            <VbenLocalePicker
              v-if="getShowLocalePicker"
              :reload="true"
              :showText="false"
            />
            <ThemeSwitch />
            <AppSearch v-if="getShowSearch" />
            <UserDropdown />
            <SettingButton v-if="getShowSetting" />
          </div>
        </slot>
      </div>
    </div>

    <template v-if="getShowHeaderMultipleTab">
      <slot name="tabs">
        <LayoutTabs />
      </slot>
    </template>
    <template v-if="getShowHeaderMultipleTab">
      <slot name="bannernotice">
        <AnYiBannerNotice />
      </slot>
    </template>
  </div>
</template>

<script lang="ts" setup>
import LayoutBreadcrumb from '../components/breadcrumb/index.vue'
import ThemeSwitch from '../components/theme/index.vue'
import LayoutTabs from '../components/tabs/index.vue'
import AppSearch from '../components/search/AppSearch.vue'
import AnYiBannerNotice from '../components/AnYiBannerNotice'
import AppNotify from '../components/notify/index.vue'
import AppFullScreen from '../components/FullScreen.vue'
import { SettingButton } from '../components/setting'
import UserDropdown from '../components/user-dropdown/index.vue'
import { context } from '../../bridge'
import { computed, unref } from 'vue'
import {
  SettingButtonPositionEnum,
  ThemeEnum,
  MenuTypeEnum,
} from '@anyi/constants'
import { useAppConfig } from '@anyi/hooks'
const { isMixSidebar, isTopMenu, isMix, sidebar, menu, header } = useAppConfig()
const {
  useHeaderSetting,
  useRootSetting,
  useMenuSetting,
  useConfigStore,
  Logo,
  useAppInject,
  useMultipleTabSetting,
} = context
const {
  getShowBread,
  getShowFullScreen,
  getShowLocalePicker,
  getShowSearch,
  getShowHeader,
  getShowNotice,
  getShowFullHeaderRef,
  getShowHeaderLogo,
} = useHeaderSetting()
const { getDarkMode } = useConfigStore()
const { getSettingButtonPosition, getShowSettingButton } = useRootSetting()
const { getMenuType, getMenuWidth, getIsTopMenu, getMenuShowLogo } =
  useMenuSetting() as any
const { getIsMobile } = useAppInject()
const { getShowMultipleTab } = useMultipleTabSetting()
const isDark = computed(() => getDarkMode == ThemeEnum.DARK)
const getShowSetting = computed(() => {
  if (!unref(getShowSettingButton)) {
    return false
  }
  const settingButtonPosition = unref(getSettingButtonPosition)

  if (settingButtonPosition === SettingButtonPositionEnum.AUTO) {
    return unref(getShowHeader)
  }
  return settingButtonPosition === SettingButtonPositionEnum.HEADER
})
console.log('------getMenuShowLogo-----', getMenuShowLogo)
const getShowHeaderMultipleTab = computed(() => {
  return (
    unref(getShowMultipleTab) &&
    (unref(getMenuType) !== MenuTypeEnum.MIX || unref(getIsMobile))
  )
})
const showHeaderLogo = computed(() => {
  return unref(isTopMenu) || unref(isMix)
})
</script>

<style lang="less" scoped>
.anyi-layout-header {
  :deep(.arco-btn-icon) {
    color: rgb(var(--gray-8));
  }

  :deep(.arco-btn-outline[type='button']) {
    border-color: 1px solid rgb(var(--gray-2));
    color: rgb(var(--gray-2));
    font-size: 16px;
  }
}
</style>
