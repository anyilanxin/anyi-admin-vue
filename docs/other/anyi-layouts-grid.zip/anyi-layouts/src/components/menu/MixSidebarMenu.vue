<!--
 * Copyright (c) 2021-present ZHOUXUANHONG(安一老厨)<anyilanxin@aliyun.com>
 *
 * 本软件 AnYi Cloud Vue EE为商业授权软件。未经过商业授权禁止使用，违者必究。
 *
 * AnYi Cloud Vue EE为商业授权软件，您在使用过程中，需要注意以下几点：
 *   1.不允许在国家法律法规规定的范围外使用，如出现违法行为作者本人不承担任何责任；
 *   2.软件使用的第三方依赖皆为开源软件，如需要修改第三方依赖请遵循第三方依赖附带的开源协议，因擅自修改第三方依赖所引起的争议，作者不承担任何责任；
 *   3.不得基于AnYi Cloud EE Vue的基础，修改包装而成一个与AnYi Cloud EE、AnYi Zeebe EE、AnYi Standalone EE功能类似的程序，进行销售或发布，参与同类软件产品市场的竞争；
 *   4.不得将软件源码以任何开源方式公布出去；
 *   5.不得对授权进行出租、出售、抵押或发放子许可证；
 *   6.您可以直接使用在自己的网站或软件产品中，也可以集成到您自己的商业网站或软件产品中进行出租或销售；
 *   7.您可以对上述授权软件进行必要的修改和美化，无需公开修改或美化后的源代码；
 *   8.本软件中使用了bpmn js,使用请遵循bpmn.io开源协议：
 *     https://github.com/bpmn-io/bpmn-js/blob/develop/LICENSE
 *   9.除满足上面条款外，在其他商业领域使用不受影响。同时作者为商业授权使用者在使用过程中出现的纠纷提供协助。
 -->
<template>
  <div
    class="relative w-full h-screen transition-all-300"
    :style="{ width: `${getMenuWidth}px` }"
    v-bind="getMenuEvents"
  >
    <Logo ref="logoRef" :style="{ maxWidth: `${getMenuWidth}px` }" />
    <VbenScrollbar :style="{ height: `calc(100% - ${lagoHeight}px)` }">
      <!-- <VbenMenu
        v-model:value="activeParentPath"
        :options="parentMenuOptions"
        :root-indent="12"
        :style="getMenuItemStyles"
      /> -->
      <a-menu
        v-model:open-keys="openKeys"
        v-model:selected-keys="selectedKey"
        auto-open-selected
        auto-scroll-into-view
        :theme="theme"
        :collapsed="getMenuCollapsed"
        :level-indent="12"
        :style="getMenuItemStyles"
      >
        <SubMenu
          v-for="subItem in parentMenuOptions"
          :key="subItem.name"
          :first-menu-item="true"
          @click="throttleHandleModuleClick(subItem.path, true)"
          :menu-item="subItem"
        />
      </a-menu>
    </VbenScrollbar>
    <SecondaryBorder right class="!bg-[var(--trigger-background-color)]" />
    <SiderFooterTrigger />
    <div
      v-bind="getMenuEvents"
      class="h-full absolute top-0 transition-all-300 bg-[var(--aside-background-color)] z-666"
      :style="{
        width: `${menu.subMenuWidth}px`,
        left: `${getMenuWidth}px`,
      }"
    >
      <div
        class="truncate flex items-center justify-between relative right-1px bg-[var(--aside-background-color)]"
        :style="{ height: `${lagoHeight}px` }"
      >
        <span class="font-700 text-16px">
          {{ title }}
        </span>
        <MenuFixedTrigger class="hover:bg-inherit" />
        <SecondaryBorder bottom class="!bg-[var(--trigger-background-color)]" />
      </div>
      <VbenScrollbar :style="{ height: `calc(100% - ${lagoHeight}px)` }">
        <!-- <VbenMenu
          ref="childrenMenuRef"
          v-model:value="activeChildrenKey"
          :options="childrenMenuOptions"
          :root-indent="12"
        /> -->
        <a-menu
          v-model:open-keys="openChildKeys"
          v-model:selected-keys="selectedChildKey"
          auto-open-selected
          :theme="theme"
          auto-scroll-into-view
          :level-indent="12"
          :style="getMenuItemStyles"
        >
          <SubMenu
            v-for="subItem in childrenMenuOptions"
            :key="subItem.name"
            :enableCollapsed="false"
            :first-menu-item="true"
            :menu-item="subItem"
          />
        </a-menu>
      </VbenScrollbar>
    </div>
  </div>
</template>

<script lang="ts" setup>
import Logo from '../logo/index.vue'
import { ref, unref, nextTick, onMounted, computed, watchEffect } from 'vue'
import { renderMenuLabel, renderMenuLabelToRouterLink } from './renderMenu'
import { useAppConfig, useGo, useSiteGeneral, useAppTheme } from '@anyi/hooks'
import { useThrottleFn } from '@anyi/utils'
import { MixSidebarTriggerEnum } from '@anyi/constants'
import SubMenu from './components/SubMenu.vue'
import {
  getChildrenMenus,
  getCurrentParentPath,
  getShallowMenus,
  listenerRouteChange,
} from '@anyi/router'
import { RouteLocationNormalized } from '@anyi/router'
import { mapTree, useElementSize, MaybeComputedElementRef, cloneDeep, getTheme } from '@anyi/utils'
import SiderFooterTrigger from '../widgets/SiderFooterTrigger.vue'
import SecondaryBorder from '../comm/SecondaryBorder.vue'
import MenuFixedTrigger from '../widgets/MenuFixedTrigger.vue'
import { Menu } from '@anyi/types'
const { menu, sidebar, getMenuStyles, closeMixSidebarOnChange, setAppConfig, isMixSidebar } =
  useAppConfig()

const { isDark } = useAppTheme()
const { title } = useSiteGeneral()

const openKeys = ref<string[]>([])
const selectedKey = ref<string[]>([])

const openChildKeys = ref<string[]>([])
const selectedChildKey = ref<string[]>([])
const activeParentPath = ref('')
const parentMenuOptions = ref<any[]>([])
const menuModules = ref<any[]>([])

const activeChildrenKey = ref('')
const childrenMenuOptions = ref([])
const theme = computed(() => {
  if (unref(isDark)) {
    return 'dark'
  }
  return getTheme(unref(sidebar).bgColor)
})
const childrenMenuRef = ref(null)
const logoRef = ref<Element>(null)
const openMenu = ref(false)
const { height: lagoHeight } = useElementSize(logoRef as MaybeComputedElementRef)

const getMenuCollapsed = computed(() => {
  return unref(sidebar).collapsed
})
const currentRoute = ref<Nullable<RouteLocationNormalized>>(null)
const go = useGo()

const throttleHandleModuleClick = useThrottleFn(handleModuleClick, 50)

watchEffect(async () =>
  setAppConfig({
    menu: { subMenuWidth: unref(openMenu) ? unref(sidebar).width : 0 },
  }),
)

onMounted(async () => {
  const menus = await getShallowMenus()
  menuModules.value = cloneDeep(menus)
  // parentMenuOptions.value = mapTree(menus, {
  //   conversion: (menu) => renderMenuLabel(menu, unref(getItemEvents)),
  // })
  parentMenuOptions.value = menus

  const currPath = unref(currentRoute).path
  if (currPath) {
    activeChildrenKey.value = currPath
    let parentPath = await getCurrentParentPath(currPath)
    if (parentPath) {
      activeParentPath.value = parentPath
    }
    // showOption()
  }
})

// Process module menu click
async function handleModuleClick(path: string, hover = false) {
  console.log('---handleModuleClickhandleModuleClickhandleModuleClick-------')
  openMenu.value = true
  const children = await getChildrenMenus(path)
  if (unref(activeParentPath) === path) {
    if (!hover) {
      if (!unref(openMenu)) {
        openMenu.value = true
      } else {
        closeMenu()
      }
    } else {
      if (!unref(openMenu)) {
        openMenu.value = true
      }
    }
    if (!unref(openMenu)) {
      await setActive()
    }
  } else {
    openMenu.value = true
    activeParentPath.value = path
  }

  if (!children || children.length === 0) {
    if (!hover) go(path)
    childrenMenuOptions.value = []
    openMenu.value = false
    return
  }
  // childrenMenuOptions.value = mapTree(children, {
  //   conversion: (menu) => renderMenuLabelToRouterLink(menu),
  // })
  childrenMenuOptions.value = children
  // showOption()
}

listenerRouteChange((route) => {
  currentRoute.value = route
  setActive(true)
  if (unref(closeMixSidebarOnChange)) {
    closeMenu()
  }
})

async function setActive(setChildren = false) {
  const path = currentRoute.value?.path
  if (!path) return
  activeParentPath.value = await getCurrentParentPath(path)
  if (unref(menu).mixSideFixed) {
    const activeMenu = unref(menuModules).find((item) => item.path === unref(activeParentPath))
    const p = activeMenu?.path
    if (p) {
      const children = await getChildrenMenus(p)
      if (setChildren) {
        // childrenMenuOptions.value = mapTree(children, {
        //   conversion: (menu) => renderMenuLabelToRouterLink(menu),
        // })
        childrenMenuOptions.value = children
        if (unref(menu).mixSideFixed) {
          openMenu.value = children.length > 0
        }
      }
      if (children.length === 0) {
        childrenMenuOptions.value = []
        openMenu.value = false
      }
    }
  }
  // showOption()
}
function closeMenu() {
  if (unref(menu).mixSideFixed) return
  openMenu.value = false
}

const getMenuEvents = computed(() => {
  return !unref(menu).mixSideFixed
    ? {
        onMouseleave: () => {
          setActive(true)
          closeMenu()
        },
      }
    : {}
})
const getMenuItemStyles = computed(() => {
  const styles = { ...getMenuStyles() }
  if (!unref(sidebar).collapsed) {
    styles['--n-item-height'] = `54px`
  }
  return styles
})

const getMenuWidth = computed(() => {
  if (unref(sidebar).collapsed) return unref(sidebar).collapsedWidth
  return unref(sidebar).mixSidebarWidth
})
</script>

<style lang="less" scoped>
:deep(.arco-menu-vertical .arco-menu-item.arco-menu-has-icon) {
  flex-direction: column;
}

:deep(.arco-menu-dark .arco-menu-item.arco-menu-selected) {
  color: rgb(var(--primary-6));
}

:deep(.arco-menu-light .arco-menu-item.arco-menu-selected) {
  color: rgb(var(--primary-6));
}
</style>
